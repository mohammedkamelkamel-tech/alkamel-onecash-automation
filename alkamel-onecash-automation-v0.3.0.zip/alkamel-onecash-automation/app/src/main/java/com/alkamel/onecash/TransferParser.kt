package com.alkamel.onecash

object TransferParser {
    data class ParsedTransfer(val amount: Double, val senderName: String, val rawText: String)

    fun parse(raw: String): ParsedTransfer? {
        val normalized = normalizeDigits(raw).replace(',', '.')
        if (!normalized.contains("استلمت")) return null
        val amount = Regex("استلمت\\s*([0-9]+(?:\\.[0-9]{1,2})?)")
            .find(normalized)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
        val senderLine = Regex("(?:^|\\n)\\s*من\\s*([^\\n\\r]+)", RegexOption.MULTILINE)
            .find(normalized)?.groupValues?.get(1)?.trim() ?: return null
        val sender = senderLine.substringBefore("رصيدك").trim().trimEnd('.', '،')
        if (sender.isBlank() || sender.contains("رصيدك")) return null
        return ParsedTransfer(amount, sender, raw)
    }

    fun normalizeDigits(text: String): String {
        val arabic = "٠١٢٣٤٥٦٧٨٩"
        val persian = "۰۱۲۳۴۵۶۷۸۹"
        return buildString { text.forEach { c -> when {
            c in arabic -> append(arabic.indexOf(c))
            c in persian -> append(persian.indexOf(c))
            else -> append(c)
        } } }
    }

    fun normalizeName(name: String): String = normalizeDigits(name.trim())
        .replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
        .replace("ى", "ي").replace("ة", "ه")
        .replace(Regex("\\s+"), " ").trim()
}
