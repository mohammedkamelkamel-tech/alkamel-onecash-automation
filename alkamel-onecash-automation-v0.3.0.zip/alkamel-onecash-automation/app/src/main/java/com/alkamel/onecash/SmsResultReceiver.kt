package com.alkamel.onecash

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager

class SmsResultReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){if(intent.action!=SmsSender.ACTION_SENT)return
  val transfer=intent.getLongExtra("transfer_id",0);val card=intent.getLongExtra("card_id",0);val phone=intent.getStringExtra("phone")?:return;val category=intent.getDoubleExtra("category",0.0);val code=intent.getStringExtra("code")?:return
  val success=resultCode==android.app.Activity.RESULT_OK
  val error=when(resultCode){SmsManager.RESULT_ERROR_GENERIC_FAILURE->"فشل عام في إرسال SMS";SmsManager.RESULT_ERROR_NO_SERVICE->"لا توجد خدمة شبكة";SmsManager.RESULT_ERROR_NULL_PDU->"بيانات SMS غير صالحة";SmsManager.RESULT_ERROR_RADIO_OFF->"الشبكة أو الراديو مغلق";else->"فشل إرسال SMS"}
  AppDatabase(context).finishSms(transfer,card,phone,category,code,success,if(success)null else error)
 }
}
