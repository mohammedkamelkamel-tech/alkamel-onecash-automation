package com.alkamel.onecash

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabase(context: Context) : SQLiteOpenHelper(context, "onecash_local.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE transfers(id INTEGER PRIMARY KEY AUTOINCREMENT, fingerprint TEXT UNIQUE, sender_name TEXT, amount REAL, raw_message TEXT, received_at INTEGER, status TEXT DEFAULT 'مراجعة', customer_phone TEXT, card_code TEXT, error TEXT)")
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, sender_name TEXT UNIQUE, normalized_name TEXT, phone TEXT, created_at INTEGER)")
        db.execSQL("CREATE INDEX idx_customers_normalized ON customers(normalized_name)")
        db.execSQL("CREATE TABLE cards(id INTEGER PRIMARY KEY AUTOINCREMENT, category REAL, card_code TEXT UNIQUE, status TEXT DEFAULT 'متوفر', added_at INTEGER, transfer_id INTEGER)")
        db.execSQL("CREATE TABLE sent_cards(id INTEGER PRIMARY KEY AUTOINCREMENT, transfer_id INTEGER UNIQUE, customer_phone TEXT, category REAL, card_code TEXT, sent_at INTEGER, sms_status TEXT)")
        db.execSQL("CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)")
        db.execSQL("INSERT INTO settings(key,value) VALUES('auto_send','0')")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE transfers ADD COLUMN customer_phone TEXT")
            db.execSQL("ALTER TABLE transfers ADD COLUMN card_code TEXT")
            db.execSQL("ALTER TABLE transfers ADD COLUMN error TEXT")
            db.execSQL("ALTER TABLE cards ADD COLUMN transfer_id INTEGER")
            db.execSQL("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT)")
            db.execSQL("INSERT OR IGNORE INTO settings(key,value) VALUES('auto_send','0')")
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE customers ADD COLUMN normalized_name TEXT")
            db.execSQL("UPDATE customers SET normalized_name=sender_name WHERE normalized_name IS NULL")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_customers_normalized ON customers(normalized_name)")
        }
    }

    fun addTransfer(fingerprint: String, sender: String, amount: Double, raw: String): Long {
        val values = ContentValues().apply {
            put("fingerprint", fingerprint); put("sender_name", sender); put("amount", amount)
            put("raw_message", raw); put("received_at", System.currentTimeMillis()); put("status", "مراجعة")
        }
        return writableDatabase.insertWithOnConflict("transfers", null, values, SQLiteDatabase.CONFLICT_IGNORE)
    }
    fun markPossibleDuplicate(id: Long, senderName: String, amount: Double, windowMs: Long = 5 * 60 * 1000): Boolean {
        val now=System.currentTimeMillis(); val normalized=TransferParser.normalizeName(senderName)
        val db=readableDatabase
        db.rawQuery("SELECT sender_name FROM transfers WHERE id<>? AND amount=? AND received_at BETWEEN ? AND ?", arrayOf(id.toString(),amount.toString(),(now-windowMs).toString(),now.toString())).use { c ->
            while(c.moveToNext()) if(TransferParser.normalizeName(c.getString(0))==normalized) {
                setTransferStatus(writableDatabase,id,"تكرار محتمل","حوالة بنفس الاسم والمبلغ خلال آخر 5 دقائق؛ تحقق قبل الإرسال")
                return true
            }
        }
        return false
    }
    fun checkpointForBackup() { writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() } }
    fun getAutoSend() = getSetting("auto_send") == "1"
    fun setAutoSend(enabled: Boolean) = setSetting("auto_send", if(enabled) "1" else "0")
    fun getSmsSenderFilter(): String = getSetting("sms_sender_filter") ?: ""
    fun setSmsSenderFilter(value: String) = setSetting("sms_sender_filter", value.trim())
    fun getSetting(key:String):String? = readableDatabase.rawQuery("SELECT value FROM settings WHERE key=?", arrayOf(key)).use { if(it.moveToFirst()) it.getString(0) else null }
    fun setSetting(key:String,value:String) { val cv=ContentValues().apply{put("key",key);put("value",value)}; writableDatabase.insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE) }
    fun transferCount(): Int = count("transfers")
    fun reviewCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM transfers WHERE status IN ('مراجعة','اسم غير مسجل','اسم متشابه','لا يوجد مخزون','فشل الإرسال','تكرار محتمل')", null).use { if(it.moveToFirst())it.getInt(0) else 0 }
    fun sentCount(): Int = count("sent_cards")
    fun cardCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM cards WHERE status='متوفر'", null).use { if(it.moveToFirst())it.getInt(0) else 0 }
    fun count(table:String):Int=readableDatabase.rawQuery("SELECT COUNT(*) FROM $table",null).use{if(it.moveToFirst())it.getInt(0)else 0}
    fun cardsByCategory():List<Pair<Double,Int>> { val out=mutableListOf<Pair<Double,Int>>(); readableDatabase.rawQuery("SELECT category,COUNT(*) FROM cards WHERE status='متوفر' GROUP BY category ORDER BY category",null).use{while(it.moveToNext())out.add(it.getDouble(0) to it.getInt(1))};return out }
    fun recentTransferIds(limit:Int=50):List<Long>{val ids=mutableListOf<Long>();readableDatabase.rawQuery("SELECT id FROM transfers ORDER BY received_at DESC LIMIT ?",arrayOf(limit.toString())).use{while(it.moveToNext())ids.add(it.getLong(0))};return ids}
    fun recentTransfers(limit:Int=50):List<String>{ val result=mutableListOf<String>(); readableDatabase.rawQuery("SELECT sender_name,amount,status,received_at,error FROM transfers ORDER BY received_at DESC LIMIT ?",arrayOf(limit.toString())).use{c->while(c.moveToNext()){val date=java.text.SimpleDateFormat("yyyy/MM/dd HH:mm",java.util.Locale.getDefault()).format(java.util.Date(c.getLong(3)));result.add("$date\n${c.getString(0)} — ${c.getDouble(1)} ريال\nالحالة: ${c.getString(2)}${c.getString(4)?.let{"\n$it"}?:""}")}};return result }
    fun customerList():List<Pair<String,String>>{val l=mutableListOf<Pair<String,String>>();readableDatabase.rawQuery("SELECT sender_name,phone FROM customers ORDER BY sender_name",null).use{while(it.moveToNext())l.add(it.getString(0) to it.getString(1))};return l}
    fun saveCustomer(name:String,phone:String):Boolean{val normalized=TransferParser.normalizeName(name);val cv=ContentValues().apply{put("sender_name",name.trim());put("normalized_name",normalized);put("phone",phone.trim());put("created_at",System.currentTimeMillis())};return writableDatabase.insertWithOnConflict("customers",null,cv,SQLiteDatabase.CONFLICT_REPLACE)!=-1L}
    fun deleteCustomer(name:String){writableDatabase.delete("customers","sender_name=?",arrayOf(name))}
    fun importCards(category:Double,codes:List<String>):Int{val db=writableDatabase;var added=0;db.beginTransaction();try{codes.filter{it.isNotBlank()}.forEach{code->val cv=ContentValues().apply{put("category",category);put("card_code",code.trim());put("status","متوفر");put("added_at",System.currentTimeMillis())};if(db.insertWithOnConflict("cards",null,cv,SQLiteDatabase.CONFLICT_IGNORE)!=-1L)added++};db.setTransactionSuccessful()}finally{db.endTransaction()};return added}
    fun listCards():List<String>{val l=mutableListOf<String>();readableDatabase.rawQuery("SELECT category,COUNT(*) FROM cards WHERE status='متوفر' GROUP BY category ORDER BY category",null).use{while(it.moveToNext())l.add("${it.getDouble(0).toInt()} ريال: ${it.getInt(1)} كرت")};return l}
    fun processTransfer(transferId:Long):ProcessResult {
        val db=writableDatabase;db.beginTransaction();try{
            val t=db.rawQuery("SELECT sender_name,amount,status FROM transfers WHERE id=?",arrayOf(transferId.toString()))
            if(!t.moveToFirst()){t.close();return ProcessResult(false,"الحوالة غير موجودة")};val name=t.getString(0);val amount=t.getDouble(1);val status=t.getString(2);t.close()
            if(status=="تم الإرسال"||status=="جارٍ الإرسال")return ProcessResult(false,"الحوالة معالجة مسبقًا")
            val normalizedName=TransferParser.normalizeName(name)
            val customer=db.rawQuery("SELECT phone,sender_name FROM customers WHERE normalized_name=? OR sender_name=?",arrayOf(normalizedName,name.trim()))
            if(!customer.moveToFirst()){customer.close();setTransferStatus(db,transferId,"اسم غير مسجل","لا يوجد رقم مرتبط بالاسم");db.setTransactionSuccessful();return ProcessResult(false,"الاسم غير مسجل")}
            val phone=customer.getString(0)
            if(customer.moveToNext()){customer.close();setTransferStatus(db,transferId,"اسم متشابه","يوجد أكثر من سجل باسم متطابق/متشابه؛ راجع الربط يدويًا");db.setTransactionSuccessful();return ProcessResult(false,"تطابق الاسم غير فريد، يلزم مراجعة")}
            customer.close()
            val card=db.rawQuery("SELECT id,card_code FROM cards WHERE category=? AND status='متوفر' ORDER BY id LIMIT 1",arrayOf(amount.toString()))
            if(!card.moveToFirst()){card.close();setTransferStatus(db,transferId,"لا يوجد مخزون","لا يوجد كرت لهذه الفئة");db.setTransactionSuccessful();return ProcessResult(false,"لا يوجد كرت للفئة")};val cardId=card.getLong(0);val code=card.getString(1);card.close()
            val cv=ContentValues().apply{put("status","محجوز");put("transfer_id",transferId)};db.update("cards",cv,"id=? AND status='متوفر'",arrayOf(cardId.toString()))
            val tv=ContentValues().apply{put("status","جارٍ الإرسال");put("customer_phone",phone);put("card_code",code);put("error",null)};db.update("transfers",tv,"id=?",arrayOf(transferId.toString()))
            db.setTransactionSuccessful();return ProcessResult(true,"",phone,code,amount,transferId,cardId)
        }finally{db.endTransaction()}}
    fun finishSms(transferId:Long,cardId:Long,phone:String,category:Double,code:String,success:Boolean,error:String?){val db=writableDatabase;db.beginTransaction();try{if(success){val cv=ContentValues().apply{put("status","مرسل");put("transfer_id",transferId)};db.update("cards",cv,"id=?",arrayOf(cardId.toString()));val sv=ContentValues().apply{put("transfer_id",transferId);put("customer_phone",phone);put("category",category);put("card_code",code);put("sent_at",System.currentTimeMillis());put("sms_status","تم الإرسال")};db.insertWithOnConflict("sent_cards",null,sv,SQLiteDatabase.CONFLICT_IGNORE);setTransferStatus(db,transferId,"تم الإرسال",null)}else{db.update("cards",ContentValues().apply{put("status","متوفر");put("transfer_id",null)},"id=?",arrayOf(cardId.toString()));setTransferStatus(db,transferId,"فشل الإرسال",error)}}finally{db.setTransactionSuccessful();db.endTransaction()}}
    fun markManualReview(id:Long){setTransferStatus(writableDatabase,id,"مراجعة",null)}
    private fun setTransferStatus(db:SQLiteDatabase,id:Long,status:String,error:String?){val cv=ContentValues().apply{put("status",status);put("error",error)};db.update("transfers",cv,"id=?",arrayOf(id.toString()))}
    data class ProcessResult(val ready:Boolean,val message:String,val phone:String="",val code:String="",val category:Double=0.0,val transferId:Long=0,val cardId:Long=0)
}
