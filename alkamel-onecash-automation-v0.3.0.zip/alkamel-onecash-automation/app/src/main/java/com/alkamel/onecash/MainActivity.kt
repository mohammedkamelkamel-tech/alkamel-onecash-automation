package com.alkamel.onecash

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.File

class MainActivity : Activity() {
    private lateinit var db: AppDatabase
    private lateinit var root: LinearLayout
    private var selectedCategory = 100.0
    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) importFile(uri) }
    private val backupPicker = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri -> if(uri!=null) exportBackup(uri) }
    private val restorePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if(uri!=null) restoreBackup(uri) }
    private val permissions = arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = AppDatabase(this)
        buildUi()
        if (permissions.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) requestPermissions(permissions, 77)
    }
    override fun onResume() { super.onResume(); if (::root.isInitialized) buildUi() }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,16,18,20); layoutDirection=LinearLayout.LAYOUT_DIRECTION_RTL; setBackgroundColor(0xFFF2F6FA.toInt()) }
        root.addView(TextView(this).apply { text="الكامل — أتمتة ون كاش"; textSize=23f; gravity=Gravity.CENTER; setTextColor(0xFF12304A.toInt()); setPadding(4,14,4,8) })
        root.addView(TextView(this).apply { text="استقبال الحوالات • ربط الأسماء • إرسال الكروت SMS"; textSize=13f; gravity=Gravity.CENTER; setTextColor(0xFF506575.toInt()); setPadding(4,0,4,16) })
        stat("الحوالات المسجلة",db.transferCount()); stat("تحتاج مراجعة",db.reviewCount()); stat("كروت متوفرة",db.cardCount()); stat("كروت مرسلة",db.sentCount())
        button("إدارة العملاء وربط الاسم بالجوال", ::customers)
        button("الحوالات الواردة ومراجعتها", ::transfers)
        button("استيراد مخزون الكروت TXT", ::chooseCategory)
        button("مخزون الكروت حسب الفئة", ::cards)
        button("الإعدادات والأتمتة", ::settings)
        button("تصدير نسخة احتياطية", { backupPicker.launch("alkamel-onecash-backup.db") })
        button("استعادة نسخة احتياطية", { restorePicker.launch(arrayOf("application/octet-stream", "application/x-sqlite3", "application/vnd.sqlite3", "*/*")) })
        val warning = if(db.getAutoSend()) "الإرسال التلقائي مفعّل. تأكد من ربط الأسماء ومخزون الكروت ومرسل SMS." else "الإرسال التلقائي مغلق. اختبر الرسائل والربط والمخزون قبل تفعيله."
        root.addView(TextView(this).apply { text=warning; textSize=13f; setTextColor(if(db.getAutoSend())0xFF9A3D00.toInt() else 0xFF8A5A00.toInt()); setPadding(8,16,8,8) })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun stat(label:String,value:Int) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(14,12,14,12); setBackgroundColor(0xFFFFFFFF.toInt()) }
        row.addView(TextView(this).apply { text=label; textSize=15f; setTextColor(0xFF18334A.toInt()); layoutParams=LinearLayout.LayoutParams(0,-2,1f) })
        row.addView(TextView(this).apply { text=value.toString(); textSize=21f; setTextColor(0xFF0785C4.toInt()) })
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=7; root.addView(row,lp)
    }
    private fun button(text:String,action:()->Unit) { val b=Button(this).apply { this.text=text; textSize=15f; setOnClickListener { action() } }; val p=LinearLayout.LayoutParams(-1,-2);p.topMargin=5;root.addView(b,p) }

    private fun customers() {
        val customers=db.customerList(); val labels=customers.map { "${it.first}\n${it.second}" }.toMutableList(); labels.add("＋ إضافة عميل جديد")
        AlertDialog.Builder(this).setTitle("العملاء (${customers.size})").setItems(labels.toTypedArray()) { _,which -> if(which==labels.lastIndex) addCustomer() else customerActions(customers[which].first,customers[which].second) }
            .setPositiveButton("إضافة",null).setNegativeButton("إغلاق",null).show().apply { getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { addCustomer() } }
    }
    private fun addCustomer(existingName:String="",existingPhone:String="") {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,10,20,0) }
        val name=EditText(this).apply { hint="اسم المحوّل كما يظهر في SMS ون كاش"; setText(existingName) }
        val phone=EditText(this).apply { hint="رقم الهاتف الذي يستلم الكرت"; setText(existingPhone); inputType=3 }
        box.addView(name);box.addView(phone)
        AlertDialog.Builder(this).setTitle(if(existingName.isEmpty())"إضافة ربط اسم/جوال" else "تعديل الربط").setView(box).setPositiveButton("حفظ") { _,_ ->
            val n=name.text.toString().trim();val p=phone.text.toString().trim()
            if(n.isBlank()||p.filter{it.isDigit()}.length<9) toast("أدخل الاسم ورقم جوال صحيح") else if(db.saveCustomer(n,p)){toast("تم حفظ الربط");buildUi()}else toast("تعذر حفظ الربط")
        }.setNegativeButton("إلغاء",null).show()
    }
    private fun customerActions(name:String,phone:String) { AlertDialog.Builder(this).setTitle(name).setMessage(phone).setItems(arrayOf("تعديل","حذف")) { _,i -> if(i==0)addCustomer(name,phone) else AlertDialog.Builder(this).setMessage("حذف ربط الاسم؟ لن يحذف سجل الحوالات.").setPositiveButton("حذف") { _,_ -> db.deleteCustomer(name);buildUi() }.setNegativeButton("إلغاء",null).show() }.setNegativeButton("رجوع",null).show() }

    private fun transfers() {
        val entries=db.recentTransfers();val ids=db.recentTransferIds()
        if(entries.isEmpty()){toast("لا توجد حوالات حتى الآن");return}
        AlertDialog.Builder(this).setTitle("الحوالات الأخيرة (${entries.size})").setItems(entries.toTypedArray()) { _,i -> transferActions(ids[i],entries[i]) }.setNegativeButton("إغلاق",null).show()
    }
    private fun transferActions(id:Long,details:String) {
        AlertDialog.Builder(this).setTitle("تفاصيل الحوالة").setMessage(details).setPositiveButton("معالجة وإرسال الكرت") { _,_ ->
            val result=db.processTransfer(id); if(result.ready){SmsSender.send(this,result);toast("بدأ إرسال SMS. انتظر نتيجة الإرسال.")}else toast(result.message);buildUi()
        }.setNeutralButton("إعادة للمراجعة") { _,_ -> db.markManualReview(id);buildUi() }.setNegativeButton("إغلاق",null).show()
    }

    private fun chooseCategory() {
        val cats=arrayOf("100 ريال","200 ريال","250 ريال","500 ريال","فئة أخرى")
        AlertDialog.Builder(this).setTitle("فئة الكروت").setItems(cats) { _,i -> if(i<4){selectedCategory=doubleArrayOf(100.0,200.0,250.0,500.0)[i];filePicker.launch("text/plain")}else customCategory() }.show()
    }
    private fun customCategory() {
        val input=EditText(this).apply{hint="قيمة الفئة بالريال";inputType=2}
        AlertDialog.Builder(this).setTitle("فئة جديدة").setView(input).setPositiveButton("اختيار ملف") { _,_ -> val v=input.text.toString().toDoubleOrNull();if(v==null||v<=0)toast("فئة غير صحيحة")else{selectedCategory=v;filePicker.launch("text/plain")} }.setNegativeButton("إلغاء",null).show()
    }
    private fun importFile(uri:Uri) {
        try { val text=contentResolver.openInputStream(uri)?.use{BufferedReader(InputStreamReader(it)).readText()}?:"";val codes=text.lines().map{it.trim()}.filter{it.isNotEmpty()};val added=db.importCards(selectedCategory,codes);toast("تم استيراد $added كرت إلى فئة ${selectedCategory.toInt()} ريال");buildUi() }
        catch(e:Exception){toast("فشل استيراد الملف: ${e.message}")}
    }
    private fun cards() { val lines=db.listCards(); AlertDialog.Builder(this).setTitle("المخزون المتوفر").setMessage(if(lines.isEmpty())"المخزون فارغ"else lines.joinToString("\n")).setPositiveButton("حسنًا",null).show() }

    private fun settings() {
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,8,20,0)}
        val auto=CheckBox(this).apply{text="تفعيل الإرسال التلقائي عند الحوالة المطابقة";isChecked=db.getAutoSend()}
        val filter=EditText(this).apply{hint="مرسل SMS ون كاش (اختياري، كما يظهر في الهاتف)";setText(db.getSmsSenderFilter())}
        layout.addView(auto);layout.addView(filter)
        AlertDialog.Builder(this).setTitle("الإعدادات").setView(layout).setMessage("اترك حقل المرسل فارغًا أثناء التجربة. بعد معرفة عنوان/اسم مرسل ون كاش، أدخله لتصفية الرسائل. الإرسال التلقائي يرسل فقط عند تطابق الاسم المسجل والمبلغ وتوفر كرت.")
             .setPositiveButton("حفظ") { _,_ ->
                val senderValue=filter.text.toString().trim()
                if(auto.isChecked && senderValue.isBlank()) {
                    toast("يلزم تحديد مرسل ون كاش الموثوق قبل تفعيل الإرسال التلقائي")
                    db.setAutoSend(false)
                } else if(auto.isChecked && permissions.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
                    toast("لا يمكن تفعيل التلقائي قبل منح صلاحيات SMS")
                    requestPermissions(permissions,77)
                    db.setAutoSend(false)
                } else db.setAutoSend(auto.isChecked)
                db.setSmsSenderFilter(senderValue);toast("تم حفظ الإعدادات");buildUi()
            }.setNegativeButton("إلغاء",null).show()
    }
    private fun exportBackup(uri:Uri) { try { db.checkpointForBackup(); val dbFile=getDatabasePath("onecash_local.db");contentResolver.openOutputStream(uri)?.use{out->dbFile.inputStream().use{it.copyTo(out)}};toast("تم تصدير نسخة قاعدة البيانات") } catch(e:Exception){toast("فشل النسخ الاحتياطي: ${e.message}")} }
    private fun restoreBackup(uri:Uri) {
        AlertDialog.Builder(this).setTitle("استعادة نسخة احتياطية").setMessage("سيتم استبدال قاعدة البيانات الحالية. تأكد أن الملف نسخة من تطبيق الكامل — أتمتة ون كاش.")
            .setPositiveButton("استعادة") { _,_ -> try {
                db.close()
                val target=getDatabasePath("onecash_local.db")
                File(target.parent!!).mkdirs()
                File(target.path+"-wal").delete();File(target.path+"-shm").delete()
                val inputStream=contentResolver.openInputStream(uri) ?: throw IllegalStateException("تعذر قراءة الملف")
                val header=ByteArray(16);val read=inputStream.read(header);inputStream.close()
                if(read<16 || String(header,Charsets.US_ASCII)!="SQLite format 3\u0000") throw IllegalArgumentException("الملف ليس نسخة SQLite صحيحة")
                contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { input.copyTo(it) } } ?: throw IllegalStateException("تعذر قراءة الملف")
                db=AppDatabase(this);toast("تمت الاستعادة");buildUi()
            } catch(e:Exception) { db=AppDatabase(this);toast("فشل الاستعادة: ${e.message}");buildUi() } }
            .setNegativeButton("إلغاء",null).show()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
