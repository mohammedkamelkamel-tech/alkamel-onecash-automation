package com.alkamel.onecash

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.telephony.SmsManager

object SmsSender {
    const val ACTION_SENT="com.alkamel.onecash.SMS_SENT"
    fun send(context:Context,result:AppDatabase.ProcessResult){
        val intent=Intent(context, SmsResultReceiver::class.java).apply{action=ACTION_SENT;putExtra("transfer_id",result.transferId);putExtra("card_id",result.cardId);putExtra("phone",result.phone);putExtra("category",result.category);putExtra("code",result.code)}
        val pending=PendingIntent.getBroadcast(context,result.transferId.toInt(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val message="الكامل: كرت ${result.category.toInt()} ريال\nرقم الكرت: ${result.code}\nشكراً لك."
        try{SmsManager.getDefault().sendTextMessage(result.phone,null,message,pending,null)}catch(e:Exception){AppDatabase(context).finishSms(result.transferId,result.cardId,result.phone,result.category,result.code,false,e.message?:"تعذر إرسال SMS")}
    }
}
