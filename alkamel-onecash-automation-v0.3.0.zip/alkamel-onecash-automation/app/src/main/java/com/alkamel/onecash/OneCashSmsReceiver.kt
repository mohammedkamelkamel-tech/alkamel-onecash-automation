package com.alkamel.onecash

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import java.security.MessageDigest

class OneCashSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val db = AppDatabase(context)
        val senderFilter = db.getSmsSenderFilter().trim()
        Telephony.Sms.Intents.getMessagesFromIntent(intent).forEach { sms ->
            val body = sms.messageBody ?: return@forEach
            // Optional sender filter. Leave blank during initial testing; configure after confirming OneCash sender ID.
            if (senderFilter.isNotBlank() && !sms.originatingAddress.orEmpty().contains(senderFilter, ignoreCase = true)) return@forEach
            val parsed = TransferParser.parse(body) ?: return@forEach
            val fingerprint = sha256("${sms.originatingAddress.orEmpty()}|${sms.timestampMillis}|$body")
            val id = db.addTransfer(fingerprint, parsed.senderName, parsed.amount, body)
            if (id > 0 && db.getAutoSend() && senderFilter.isNotBlank()) {
                if (db.markPossibleDuplicate(id, parsed.senderName, parsed.amount)) return@forEach
                val result = db.processTransfer(id)
                if (result.ready) SmsSender.send(context, result)
            }
        }
    }
    private fun sha256(value: String) = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
