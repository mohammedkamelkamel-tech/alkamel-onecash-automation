package com.alkamel.onecash

import org.junit.Assert.*
import org.junit.Test

class TransferParserTest {
    @Test fun parsesTypicalOneCashMessage() {
        val message = "استلمت 100.00\nمن ماجد علي صالح ا\nرصيدك791.64 ر.ي"
        val parsed = TransferParser.parse(message)
        assertNotNull(parsed)
        assertEquals(100.0, parsed!!.amount, 0.001)
        assertEquals("ماجد علي صالح ا", parsed.senderName)
    }
    @Test fun parsesArabicDigits() {
        val parsed = TransferParser.parse("استلمت ١٠٠.٠٠\nمن ماجد علي\nرصيدك ٧٩١.٦٤")
        assertNotNull(parsed)
        assertEquals(100.0, parsed!!.amount, 0.001)
    }
    @Test fun ignoresNonTransferMessage() { assertNull(TransferParser.parse("رصيدك 200 ريال")) }
    @Test fun normalizesNameForMatching() {
        assertEquals(TransferParser.normalizeName("أحمد  علي"), TransferParser.normalizeName("احمد علي"))
    }
}
