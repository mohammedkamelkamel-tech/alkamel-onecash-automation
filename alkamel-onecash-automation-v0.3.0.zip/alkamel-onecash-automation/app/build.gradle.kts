plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alkamel.onecash"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.alkamel.onecash"
        minSdk = 23
        targetSdk = 28
        versionCode = 3
        versionName = "0.3.0"
    }
}

dependencies {
    implementation("androidx.activity:activity:1.9.3")
    testImplementation("junit:junit:4.13.2")
}
